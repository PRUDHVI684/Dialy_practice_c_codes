#include<stdio.h>
int second(int n);
int main() {
	int n;
	scanf("%d",&n);
	if(n==0) {
		printf("you supplied zero");
		return 0;
	}
	if(n<=9) {
		printf("you have supplied single digit only");
		return 0;
	}
	if(second(n)) {
		printf("%d",second(n));
	}
}

int second(int n) {
	int r, sec=0, high=0, count=0;
	while(n) {
		if(n<0)
			n=-(n);
		r=n%10;
		if(r>high) {
			sec=high;
			high=r;
		}
		else if(r>sec && r!=high) {
			sec=r;
		}
		n/=10;
		count++;
	}

	if(sec==0) {
		printf("all digits are same");
	}
	else {
		return sec;
	}
}
