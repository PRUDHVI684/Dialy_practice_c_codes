#include<stdio.h>
#include<stdlib.h>

char *getstring(){
    
    char *p=NULL;
    int i=0;
    do{
        p=realloc(p,i+1);
        p[i]=getchar();
        
    }while(p[i++]!='\n');
    p[i-1]='\0';
    return p;
}

int main(){
 
    char *s=NULL;
    printf("enter string:");
    s=getstring();
    printf("%s",s);
}