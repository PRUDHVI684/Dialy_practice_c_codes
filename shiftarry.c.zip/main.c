#include<stdio.h>
void shiftarry(int arr[],int n,char choice,int shift);
int main(){
    
    int n;
    printf("n valu");
    scanf("%d",&n);
    if(n<1 || n>100){
        printf("invalid size");
        return 0;
    }
    
    int arr[n];
    for(int i=0;i<n;i++){
        printf("enter element");
        scanf("%d",&arr[i]);
    }
    
    char choice;
    printf("choice");
    scanf(" %c",&choice);
    
    int shift;
    printf("shift");
    scanf("%d",&shift);
    
    shiftarry(arr,n,choice,shift);
    
}

void shiftarry(int arr[],int n,char choice,int shift){
    int i,j;
    while(shift>0){
        if(choice=='r'){
            for(i=n-1;i>0;i--){
                arr[i]=arr[i-1];
            }
            arr[0]=0;
        }
        if(choice=='l'){
            for(i=0;i<n-1;i++){
                arr[i]=arr[i+1];
            }
            arr[n-1]=0;
        }
        shift--;
    }
  
    
    for(i=0;i<n;i++){
        printf("%d",arr[i]);
    }
}



