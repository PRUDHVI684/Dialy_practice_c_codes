#include<stdio.h>
void myatoi(char str[]);
int main(){
    
    char str[50];
    fgets(str,sizeof(str),stdin);
    char *p=str;
    while(*p){
        if(*p=='\n'){
            *p='\0';
            break;
        }
        p++;
    }
    
    myatoi(str);
}

void myatoi(char str[]){
    
    char *ch=str;
    int sign=1;
    if(*ch=='-'){
        sign=-1;
        ch++;
        
    }int digit=0;
    while(*ch){
        printf("%d",sign*(*ch-'0'));
        ch++;
        
    }
    //printf("%d",digit);
}