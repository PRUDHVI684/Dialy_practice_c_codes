#include<stdio.h>
int insert(int arr[],int n,int index,int value);
int main(){
    int n;
    printf("enter no of elements");
    scanf("%d",&n);
    
    int *arr;
    for(int i=0;i<n;i++){
        printf("enter elements");
        scanf("%d",&arr[i]);
    }
    
    int index;
    printf("enter index value");
    scanf("%d",&index);
    
    int value;
    printf("enter value");
    scanf("%d",&value);
    
    insert(arr,n,index,value);
    
}

int insert(int *arr,int n,int index,int value){
    
    for(int i=n;i>index;i--){
        arr[i]=arr[i-1];
        
    }
    arr[index]=value;
    n++;
    
    for(int i=0;i<n;i++){
        printf("%d ",arr[i]);
    }
    
}









