#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int mystrcmp(const char *s1,const char *s2);
char *getstring();

    char *getstring(){
        char *p=NULL;
        int i=0;
        do{
            p=realloc(p,i+1);
            p[i]=getchar();
        }
        while(p[i++]!='\n');
        p[i-1]='\0';
        return p;
    }

int mystrcmp(const char *s1,const char *s2){
    
    int l1,l2,cnt=0;
    l1=strlen(s1);
    l2=strlen(s2);
    if(l1!=l2)
        return 0;
    
    else{
        for(int i=0;i<l1;i++){
            if(*s1==*s2){
                //continue;
                cnt++;
                *s1++;
                *s2++;
            }
            
            
        }
    }
    if(cnt==l1){
        return 0;
    }
    else{
        return *s1-*s2;
    }
    
}

int main(){
    char *s1,*s2;
    printf("enter s1:");
    s1=getstring();
    printf("enter s2:");
    s2=getstring();
    int val=mystrcmp(s1,s2);
    printf("%d",val);
    
    
}







