#include<stdio.h>
#include<string.h>
void palin(char str[]);
int main(){
    
    char str[50];
    fgets(str,sizeof(str),stdin);
    char *p=str;
    while(*p){
        if(*p=='\n'){
            *p='\0';
            break;
        }
        p++;
    }
    char *s;
    char t[50];
    for(s=strtok(str," ");s!=NULL;s=strtok(NULL," ")){
        
        strcpy(t,str);
        palin(s);
    
        if(strcmp(t,s)==0){
            printf("%d\n",strcmp(t,s));
            printf("palindrome");
        }
        else{
            printf("not palindrome");
        }
        for(int i=0;i<strlen(str);i++){
            if(str[i]=='\0'){
                str[i]=' ';
            }
        }
    }
}

void palin(char str[]){
    
    int l=strlen(str);
    char *p,*q;
    p=str;
    q=str+l-1;
    while(p<q){
        
        char t=*p;
        *p=*q;
        *q=t;
        p++;
        q--;
    }
}