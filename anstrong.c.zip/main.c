#include<stdio.h>
#include<string.h>
void angram(char str[],char str1[]);
int main(){
    char str[50];
    fgets(str,sizeof(str),stdin);
    char *p=str;
    while(*p){
        if(*p=='\n'){
            *p='\0';
            break;
        }
        p++;
    }
    
    char str1[50];
    fgets(str1,sizeof(str1),stdin);
    char *q=str1;
    while(*q){
        if(*q=='\n'){
            *q='\0';
            break;
        }
        q++;
    }
    angram(str,str1);
    
}

void angram(char str[],char str1[]){
    
    char *s=str;
    char *u=str1;
    int len=strlen(str);
    int count=0,cou=0;
    while(*s){
        for(int i=0;i<len;i++){
               if(*s==str1[i]){
                count++;
            }
        }
       /* for(int j=0;j<len;j++){
            if(*u==str1[j]){
                cou++;
            }
        }*/
        s++;
    }
    if(count==len && cou!=2)
        printf("Anagram string.");
    else
        printf("Not an anagram string.");
    
    
}



