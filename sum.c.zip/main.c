#include<stdio.h>
int nonrepeted(int n);
int main(){
    int n,r;
    scanf("%d",&n);
    r=nonrepeted(n);
    printf("%d",r);
}

int nonrepeted(int n){
    
    int r,digit,t,count;
    while(n){
        r=n%10;
        count=0;
        t=n;
        while(t){
            digit=t%10;
            if(digit==r){
                count++;
            }
            t/=10;
        }
            
        if(count<2){
            printf("%d",r);
        
        }
        n/=10;
    }
}