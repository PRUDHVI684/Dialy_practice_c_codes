#include<stdio.h>
void sumofarry(int arr[],int n,int k);
int main(){
    int n;
    printf("enter n");
    scanf("%d",&n);
    if(n<1 || n>100){
        printf("invalid size");
        return 0;
    }
    
    int arr[n];
    for(int i=0;i<n;i++){
        printf("enter arr");
        scanf("%d",&arr[i]);
    }
    int k;
    printf("enter k");
    scanf("%d",&k);
    
    sumofarry(arr,n,k);
}

void sumofarry(int arr[],int n,int k){
    
    int i,j,sum,high=0;
    for(i=0;i<n-k+1;i++){
        sum=0;
        for(j=i;j<k+i;j++){
            sum+=arr[j];
        }
            if(sum>high){
            high=sum;
        }
        
        
    }
    printf("%d ",high);
}