#include<stdio.h>
#include<string.h>
#include<ctype.h>
void convert(char str[]);
int main(){
    
    char str[50];
    fgets(str,sizeof(str),stdin);
    char *p=str;
    while(*p){
        if(*p=='\n'){
            *p='\0';
            break;
        }
        p++;
    }
    convert(str);
}

void convert(char str[]){
    
    int len=strlen(str);
    for(int i=0;i<len;i++){
        if(isupper(str[i])){
            str[i]=tolower(str[i]);
        }
        else if(islower(str[i])){
            str[i]=toupper(str[i]);
        }
    }
    printf("%s",str);
}