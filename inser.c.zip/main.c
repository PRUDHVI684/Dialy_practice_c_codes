    #include<stdio.h>
    #include<string.h>
    void insert(char str1[],char str2[],int n);
    int main(){
        
        char str1[50];
        fgets(str1,sizeof(str1),stdin);
        char *p=str1;
        while(*p){
            if(*p=='\n'){
                *p='\0';
                break;
            }
            p++;
        }
        
        char str2[50];
        fgets(str2,sizeof(str2),stdin);
        char *q=str2;
        while(*q){
            if(*q=='\n'){
                *q='\0';
                break;
            }
            q++;
        }
        int n;
        scanf("%d",&n);
        int len=strlen(str1);
        if(n>len){
            printf("invalid input");
            return 0;
        }
        insert(str1,str2,n);
        
    }
        
    void insert(char str1[],char str2[],int n){
        
        int len1=strlen(str1);
        int len2=strlen(str2);
        
        
            for(int i=len1;i>=n;i--){
                str1[i+len2]=str1[i];
            }
            
            for(int i=0;i<len2;i++){
                str1[n+i]=str2[i];
            }
            
        printf("%s",str1);
    
    }
