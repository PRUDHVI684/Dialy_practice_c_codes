#include<stdio.h>

int nonrepeted(int n);

int main(){

    int n;

    scanf("%d",&n);

    if(n==0){

        printf("0");

        return 0;

    }

    if(n<0){

        n=-(n);

    }

    nonrepeted(n);

    return 0;

    

    

}



int nonrepeted(int n){

    int r,t,found=0;

    int freq[10]={0};

    t=n;

    while(t){

        r=t%10;

        freq[r]++;

        t=t/10;

        

    }

    

    t=n;

    while(t){

        r=t%10;

        if(freq[r]==1){

            printf("%d ",r);

            found=1;

        }

        t=t/10;

        

    }

    if(!found){

        printf("No non-repeted digits");

    }

}



