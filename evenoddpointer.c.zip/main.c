#include<stdio.h>
void evenodd(int n,int *even, int *odd);
int main(){
    int n,even,odd;
    scanf("%d",&n);
    if(n==0){
        printf("supplied zero");
        return 0;
    }
    if(n<0){
        n=-(n);
    }
    evenodd(n,&even,&odd);
    printf("%d %d",even,odd);
    
}

void evenodd(int n,int *even,int *odd){
    int r;
    *even=0;
    *odd=0;
    while(n){
        r=n%10;
        if(r%2==0){
            (*even)++;
        }
        else{
            (*odd)++;
        }
        n=n/10;
    }
}