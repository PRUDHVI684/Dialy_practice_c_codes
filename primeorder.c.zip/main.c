#include<stdio.h>
#include<math.h>
int prime(int n);
int main(){
    int n;
    printf("enter lenght");
    scanf("%d",&n);
    int arr[n];
    for(int i=0;i<n;i++){
        printf("enter elements");
        scanf("%d",&arr[i]);
    }
    
    for(int i=0;i<n;i++){
        if(prime(arr[i])){
            printf("%d ",arr[i]);
        }
    }
    
    for(int i=0;i<n;i++){
        if(!prime(arr[i])){
            printf("%d ",arr[i]);
        }
    }
    
    
}

int prime(int n){
    if(n<2){
        return 0;
    }
    for(int i=2;i<=sqrt(n);i++){
        if(n%i==0)
            return 0;
            
    }
    return 1;
}     









