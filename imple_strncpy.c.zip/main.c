#include<stdio.h>
char *mystrncpy(char *dest,const char *src,int n);

int main(){
    char str[50];
    printf("enter src");
    fgets(str,sizeof(str),stdin);
    char *p=str;
    while(*p){
        if(*p=='\n'){
            *p='\0';
            break;
        }
        p++;
    }
    char str2[50];
    printf("enter dest");
    fgets(str2,sizeof(str2),stdin);
    char *q=str2;
    while(*q){
        if(*q=='\n'){
            *q='\0';
            break;
        }
        q++;
    }
    int n;
    printf("no of bytes");
    scanf("%d",&n);
    
    mystrncpy(str2,str,n);
    printf("%s",str2);
    
}

char *mystrncpy(char *dest,const char *src,int n){
    
    for(int i=0;i<=n;i++){
        
        dest[i]=src[i];
        
    }
    return dest;
}













