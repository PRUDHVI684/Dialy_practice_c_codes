#include<stdio.h>
#include<string.h>

char reverse(char *,int len);
int main(){
    
    char s1[50];
    fgets(s1,sizeof(s1),stdin);
    char *p=s1;
    while(*p){
        if(*p=='\n'){
            *p='\0';
            break;
        }
        p++;
    }
    
    char s2[50];
    fgets(s2,sizeof(s2),stdin);
    char *q=s2;
    while(*q){
        if(*q=='\n'){
            *q='\0';
            break;
        }
        q++;
    }
    int len=strlen(s2);
    char *a;
    while((a=strstr(s1,s2))!=NULL){
        
        reverse(a,len);
    }
    printf("%s",s1);
        
}

char reverse(char *a,int len){
    
    char *start,*end;
    start=a;
    end=start+len-1;
    

    while(start<end){
        
        char t=*start;
        *start=*end;
        *end=t;
        start++;
        end--;
    }
    return *a;
}






