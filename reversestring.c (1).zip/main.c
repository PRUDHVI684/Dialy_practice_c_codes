#include<stdio.h>
#include<string.h>
void revese(char *,int len);
int main(){
    
    char str[]="abc123454abcc1234bg";
    char *ch=str;
    char sub[]="1234";
    int len=strlen(sub);
    while((ch=strstr(ch,sub))!=NULL){
        revese(ch,len);
        ch=ch+len-1;
    }
    printf("%s",str);
    
    
    
}
void revese(char *ch,int len){
    
    char *start,*end;
    int temp;
    start=ch;
    end=start+len-1;
    while(start<end){
        temp=*start;
        *start=*end;
        *end=temp;
        start++;
        end--;
    }
    
}
