#include<stdio.h>
void dup(int arr[],int n);
int main(){
    
    int n;
    scanf("%d",&n);
    
    int arr[n];
    for(int i=0;i<n;i++){
        scanf("%d",&arr[i]);
    }
    
    dup(arr,n);
}

void dup(int arr[],int n){
    
    int i,j,k;
    for(i=0;i<n;i++){
        for(j=i+1;j<n;j++){
            
            if(arr[i]==arr[j]){
                
                for(k=j;k<n;k++){
                    
                    arr[k]=arr[k+1];
                }
                n--;
                j--;
            }
        }
    }
    for(i=0;i<n;i++){
        printf("%d ",arr[i]);
    }
    
    
}













