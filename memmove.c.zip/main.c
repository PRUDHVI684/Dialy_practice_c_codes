#include<stdio.h>
#include<string.h>
void lastocc(char str[],char ch);
int main(){
    
    char str[100];
    fgets(str,sizeof(str),stdin);
    char *p=str;
    while(*p){
        
        if(*p=='\n'){
            *p='\0';
            break;
        }
        p++;
    }
    char ch;
    scanf("%c",&ch);
    lastocc(str,ch);
    //printf("%s",str);
}

void lastocc(char str[],char ch){
    char *p=str;
    while((p=strrchr(p,ch))!=NULL){
        
        memmove(p,p+1,strlen(p+1)+1);
        
    }
    //return p;
    printf("%s",str);
}













