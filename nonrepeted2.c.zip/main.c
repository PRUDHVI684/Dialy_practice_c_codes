#include<stdio.h>
void non(int arr[],int n);
int main() {

	int n;
	scanf("%d",&n);
	if(n<1) {
		printf("invalid size");
		return 0;
	}
	else if(n>50) {
		printf("Memory Overflow");
		return 0;
	}

	int arr[n];
	for(int i=0; i<n; i++) {
		scanf("%d",&arr[i]);
	}
	non(arr,n);

}

void non(int arr[],int n) {

	int i,j,count;
	for(i=0; i<n; i++) {
		count=0;
		for(j=0; j<n; j++) {
			if(arr[i]==arr[j]) {
				count++;
			}
		}
		if(count==1) {
			printf("%d",arr[i]);
		}

	}
	if(count>1)
		printf("no non-repeated elements");
}