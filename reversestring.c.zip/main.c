#include<stdio.h>
#include<string.h>
void reverse(char str[],int len);
int main(){
    
    char str[100];
    fgets(str,sizeof(str),stdin);
    char *p=str;
    while(*p){
        if(*p=='\n'){
            *p='\0';
            break;
        
        }
        p++;
    }
    
    char sub[100];
    fgets(sub,sizeof(sub),stdin);
    char *q=sub;
    while(*q){
        if(*q=='\n'){
            *q='\0';
            break;
            
        }
        q++;
    }
    int len=strlen(sub);
    char *s;
    int found=0;
    while((s=strstr(str,sub))!=NULL){
        printf("%s\n",s);
            reverse(s,len);
            found=1;
            s=s+len;
    
    }
    if(found){
        printf("%s",str);
    }
    else{
        printf("sub string not found");
    }
    
    
}

void reverse(char str[],int len){
    
    char *start,*end;
    start=str;
    end=start+len-1;
    while(start<end){
        
        char t=*start;
        *start=*end;
        *end=t;
        start++;
        end--;
        
    }
}
