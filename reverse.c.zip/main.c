#include<stdio.h>
int rev(int *n);
int main(){
    int n;
    scanf("%d",&n);
    rev(&n);
    printf("%d",n);
}

int rev(int *n){
    int t,rev=0,r;
    t=*n;
    while(t){
        r=t%10;
        rev=rev*10+r;
        t=t/10;
    }
    *n=rev;
    
}