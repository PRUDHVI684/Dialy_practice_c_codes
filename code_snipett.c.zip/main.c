#include<stdio.h>
#include<string.h>
/*int main(){
    char str1[20]="prudhvui";
    char str2[]="prraj";
    printf("size=%d %d\n",sizeof(str1),sizeof(str2));
    printf("len=%d %d\n",strlen(str1),strlen(str2));
    //printf("%s\n",strncpy(str2,str1,5));
    printf("cmp=%d\n",strncmp(str1,str2,3));
    char *p=strchr(str1,'u');
    char *q=strrchr(str1,'u');
    printf("%s\n",p);
    printf("%s\n",q);
    
}

int main()
{
char s1[15]="visualstudio";
char *p="s";
char *q=strstr(s1,"u");
printf("%s",q);
}


int main()
{
char s[15]="@vector@";
char s1[4]="rakj";
int t=strlen(s+1);
memmove(s+2,s1,strlen(s+1));
printf("%s\n",s);
printf("%d",t);

}*/

int main()
{
char s[20]="vector";
memmove(s+4,s+2,strlen(s+2)+1);
strncpy(s+2,"**",3);
printf("%s",s);
}




















