#include<stdio.h>
#include<stdlib.h>

int main(){
    int *p;
    int size,i;
    printf("enter size");
    scanf("%d",&size);
    p=malloc(size*sizeof(int));
    if(p==NULL){
        printf("memory allocation failed");
        exit(0);
    }
    /**memory aloocation successful.............**/ 
    for(i=0;i<size;i++){
        printf("enter elemet:");
        scanf("%d",&p[i]);
        
    }
    for(i=0;i<size;i++){
        printf("%d",p[i]);
    }
    printf("\n");
    printf("realocation of memory");
    printf("\n");
    
    p=realloc(p,(size/2)*sizeof(int));
    
    for(i=0;i<(size/2);i++){
        printf("enter elemet:");
        scanf("%d",&p[i]);
    }
    
    for(i=0;i<(size/2);i++){
        printf("%d",p[i]);
    }
    printf("\n");
    
}











