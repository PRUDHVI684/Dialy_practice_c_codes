#include<stdio.h>
#define ROW 4
#define COL 6

void input(float (*)[COL],int,int);
void print(float(*)[COL],int ,int);
int main(){
    float MARKS[ROW][COL];
    input(MARKS,ROW,COL);
    print(MARKS,ROW,COL);
    
    
    
}

void input(float (*p)[COL],int row,int col){
    int i,j;
    for(i=0;i<row;i++){
        for(j=0;j<col;j++){
            printf("enter the marksa%d:",i+1);
            scanf("%f",&p[i][j]);
        }
    }
}


void print(float (*p)[COL],int row,int col){
    int i,j;
    int total,gtotal=0;
    for(i=0;i<row;i++){
        printf("semister %d:",i+1);
        total=0;
        for(j=0;j<col;j++){
            total+=p[i][j];
            printf("%.2f,",p[i][j]);
        }
        printf("total=%.2f",total);
        printf("\n");
        gtotal+=total;
}
printf("\n");
printf("gtotal=%.2f:",gtotal);

}














