#include<stdio.h>
#include<math.h>
#include<stdlib.h>
int cnt,i;

int print(int *ptr){
    for(int i=0;i<cnt;i++){
        printf("%d ",ptr[i]);
    }    
}


int isPrime(int n){
    if(n<2)
        return 0;
    else{
        for(i=2;i<=sqrt(n);i++){
            if(n%i==0){
                return 0;
            }
        }
        return 1;
    }
}

int main(){
    
    int min,max;
    int *ptr=NULL;
    printf("enter min and max");
    scanf("%d %d",&min,&max);
    for(;min<=max;min++){
        if(isPrime(min)){
        ptr=realloc(ptr,(cnt+1)*sizeof(int));
        ptr[cnt]=min;
        cnt++;
        }
    }
    print(ptr);
    
}




