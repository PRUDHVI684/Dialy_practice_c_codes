#include<stdio.h>
#include<string.h>
void hidestring(char *,int len);
int main(){
    char str[]="abc123abc123abc";
    char *ch=str;
    char sub[]="123";
    int len=strlen(sub);
    while((ch=strstr(ch,sub))!=NULL){
        hidestring(ch,len);
        ch=ch+len;
        
    }
    printf("%s",str);
}

void hidestring(char *ch,int len){
    
    while(len>0){
        
        *ch='*';
        ch++;
        len--;
    }
    
}
    
