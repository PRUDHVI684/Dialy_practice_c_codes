#include<stdio.h>
int clear(int *n,int pos);
int main(){
    int n,pos;
    scanf("%d %d",&n,&pos);
    clear(&n,pos);
    printf("%d",n);
}

int clear(int *n,int pos){
    *n=*n &~(1<<pos);
    
}