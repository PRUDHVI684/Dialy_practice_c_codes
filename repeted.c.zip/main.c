#include<stdio.h>
int repeted(int arr[],int n);
int main(){
    int n;
    scanf("%d",&n);
    
    int arr[n];
    for(int i=0;i<n;i++){
        scanf("%d",&arr[i]);
    }
    repeted(arr,n);
    
}

int repeted(int arr[],int n){
    int i;
    int freq[100]={0};
    
    
    for(int i=0;i<n;i++){
        for(int j=i+1;j<n;j++){
            
                if(arr[i]==arr[j]){
                    freq[arr[i]]++;
                    
            }
            
        }
        if(freq[arr[i]]>0){
            printf("%d",arr[i]);
        }
    }
    if(freq[arr[i]]==0){
        printf("no repeted elements");
    }
}