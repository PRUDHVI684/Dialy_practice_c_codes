#include<stdio.h>
int main(){
    
    int i,j;
    int col=3,row=3;
    int arr[col][row];
    for(i=0;i<row;i++){
        for(j=0;j<col;j++){
            printf("enter num");
            scanf("%d",&arr[i][j]);
        }
    }
    for(int k=0;k<row*col-1;k++){
        for(i=0;i<row;i++){
            for(j=0;j<col-1;j++){
               if(arr[i][j]>arr[i][j+1]){
                   int t=arr[i][j];
                   arr[i][j]=arr[i][j+1];
                   arr[i][j+1]=t;
               }

}
}
}
    for(i=0;i<row;i++){
        for(j=0;j<col;j++){
            //rintf("enter num");
            printf("%d",arr[i][j]);
        }
        //printf("\n");
    }

}