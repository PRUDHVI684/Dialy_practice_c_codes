#include<stdio.h>
#include<string.h>
void print(char str[],char ch);
int main(){
    
    char str[100];
    fgets(str,sizeof(str),stdin);
    char *p=str;
    while(*p){
        if(*p=='\n')
            *p='\0';
        p++;
    }
    
    char ch;
    scanf("%c",&ch);
    
    print(str,ch);
}

void print(char str[],char ch){
    
    char *p=str;
    int count=0;
    while(*p){
        if(*p==ch){
            count++;
        }
        p++;
    }
    if(count>0){
        printf("%d",count);
    }
    else{
        printf("not found");
    }
}
