#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdlib.h>
#include<stdio_ext.h>
#define MAX 5
void insert(char **);
void sort(char **);
void print(char **);
char *getstring();
void delete(char **);

int cnt;

int main(){
    char choice;
    char *DB[MAX];
    while(1){
    printf("enter choice");
    printf("i.insert s.sort p.print d.delete e.exit\n");
    __fpurge(stdin);
    scanf("%c",&choice);    
    switch(choice){
        
        case 'i':insert(DB);
                 break;
        case 's':sort(DB);
                 break;
        case 'p':print(DB);
                 break;
        case 'd':delete(DB);
                 break;
        case 'e':exit(0);
    }
    }
    
}



char *getstring(){
    char *p=NULL;
    int i=0;
    __fpurge(stdin);
    do{
        p=realloc(p,i+1);
        p[i]=getchar();
        
    }while((p[i++])!='\n');
    p[i-1]=0;
    return p;
    
}



void insert(char **q){
    if(cnt==MAX){
        printf("DB is full\n");
    }
    else{
            q[cnt]=getstring();
            cnt++;
    }
    
    
}

void print(char **p){
    
    for(int i=0;i<cnt;i++){
        printf("%s\n",p[i]);
    }
}

void sort(char **p){
    
    char *t;
    for(int i=0;i<cnt-1;i++){
        for(int j=0;j<cnt-i-1;j++){
            if(strcmp(p[j],p[j+1])>0){
                t=p[j];
                p[j]=p[j+1];
                p[j+1]=t;
            }
        }
    }
}

void delete(char **p){
    
    //char *sub=NULL;
    char *ch;
    printf("enter name to delete");
    ch=getstring();
    for(int i=0;i<cnt;i++){
        
        if(!(strcmp(p[i],ch))){
            free(p[i]);
            memmove(&p[i],&p[i+1],(cnt-i-1)*sizeof(p[i]));
            cnt--;
        }
    }

}


















