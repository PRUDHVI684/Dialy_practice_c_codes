#include<stdio.h>
#include<math.h>
int prime(int n);
int single(int n);
int main(){
    int min,max,n;
    scanf("%d %d",&min,&max);
    for(n=min;n<=max;n++){
        printf("%d",prime(n));
        printf("%d",single(n));
    }
    
}

int prime(int n){
    int t,i,sq;
    sq=sqrt(n);
    for(int i=2;i<=sq;i++){
        if(i%sq==0){
            return 0;
        }
                      
    }
    return i;
}


int single(int n){
    int r,sum,sq;
    sq=sqrt(n);
    if(n>9)
        do{
            sum=0;
            r=n%10;
            sum+=r;
            n=n/10;
            
        }
        while(n>9);
    int prime(int sum);
}












