#include<stdio.h>
void toggle(int *n,int pos);
int main(){
    int n,pos;
    scanf("%d",&n);
    scanf("%d",&pos);
    toggle(&n,pos);
    printf("%d",n);
    
}


void toggle(int *n,int pos){
    *n=*n | (1<<pos);
    
}