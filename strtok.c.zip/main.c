#include<stdio.h>
#include<string.h>
int main(){
    
    char str[]="hi radar aia bib cicc hbgj";
    char *t;
    char *st,*ed;
    int count=0;
    for(t=strtok(str," ");t!=NULL;t=strtok(NULL," ")){
            int l=strlen(t);
            char d[50];
            strcpy(d,t);
            st=d;
            ed=st+l-1;
        while(st<ed){
            char t=*st;
            *st=*ed;
            *ed=t;
            st++;
            ed--;
        }
        if(strcmp(t,d)==0){
            count++;
        }
        
    }
    printf("%d",count);
    
}

