#include<stdio.h>

struct st
{
	/*short int x:10;
	short int :0;
	short int y:2;
	//short int z:7;*/
	char ch;
	int x;
	double y;

};

int main()
{
	printf("%ld",sizeof(struct st));
}