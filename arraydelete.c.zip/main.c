#include<stdio.h>
int delete(int arr[],int n,int index);
int main(){
    int n;
    printf("enter no of elements");
    scanf("%d",&n);
    
    int *arr;
    
    for(int i=0;i<n;i++){
        printf("enter elements");
        scanf("%d",&arr[i]);
        
    }
    
    int index;
    printf("enter position");
    scanf("%d",&index);
    
    
    delete(arr,n,index);
    
    
}

int delete(int arr[],int n,int index){
    for(int i=index;i<n-1;i++){
        arr[i]=arr[i+1];
    }
    
    for(int i=0;i<n-1;i++){
        printf("%d ",arr[i]);
    }
    
}















